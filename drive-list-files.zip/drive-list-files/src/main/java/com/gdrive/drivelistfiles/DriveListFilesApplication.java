package com.gdrive.drivelistfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriveListFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriveListFilesApplication.class, args);
	}
	
}
