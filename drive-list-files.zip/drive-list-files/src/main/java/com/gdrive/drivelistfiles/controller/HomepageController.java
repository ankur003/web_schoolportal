/**
 * 
 */
package com.gdrive.drivelistfiles.controller;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gdrive.drivelistfiles.enums.CompanyStatus;
import com.gdrive.drivelistfiles.utils.SheetsHelper;

/**
 * @author Ankur Bansala
 *
 */
@CrossOrigin(maxAge = 3600, origins = "*")
@RestController
public class HomepageController extends ValidatedController{
	
	private static final String SPREADSHEET_ID = "1eNXPksApmIKeZHfTVkQgoyOyAmckTbaF-ej3XgKOH_g";

	@GetMapping(value = { "/Callback" })
	public String saveAuthorizationCode(HttpServletRequest request) {
		String code = request.getParameter("code");
		if (code != null) {
			return code;
		}
		return null;
	}
	
	@GetMapping(value = { "/getDetails" })
	public ResponseEntity<Object> getDetails(@NotBlank(message = "sheetId is blank") @RequestParam("sheetId") String sheetId
			,@NotNull(message = "companyStatus is blank or invalid - should be [GAINER OR LOOSER] ") @RequestParam("companyStatus") CompanyStatus companyStatus
			,@NotNull(message = "lastDaysCount is blank or invalid should be less then equal to 30 ") @RequestParam("lastDaysCount") Integer lastDaysCount,
			@NotNull(message = "companiesCount is blank or invalid ") @RequestParam("companiesCount") Integer companiesCount
			) throws IOException, GeneralSecurityException {
		Map<String, List<Double>> detailsMap = SheetsHelper.getDetails(sheetId, companyStatus, lastDaysCount, companiesCount);
		if(detailsMap == null || detailsMap.isEmpty()) {
			return	ResponseEntity.noContent().build();
		}
		return ResponseEntity.ok(detailsMap);

	}
	
}