package com.gdrive.drivelistfiles.controller;

import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;

@Validated
@Controller
public class ValidatedController {

}
