package com.gdrive.drivelistfiles.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.gdrive.drivelistfiles.enums.CompanyStatus;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;

public class SheetsHelper {
	private static final String APPLICATION_NAME = "Google Sheets API Java Quickstart";
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens";

	/**
	 * Global instance of the scopes required by this quickstart. If modifying these
	 * scopes, delete your previously saved tokens/ folder.
	 */
	private static final List<String> SCOPES = Collections.singletonList(SheetsScopes.SPREADSHEETS_READONLY);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	/**
	 * Creates an authorized Credential object.
	 * 
	 * @param httpTransport The network HTTP Transport.
	 * @return An authorized Credential object.
	 * @throws IOException If the credentials.json file cannot be found.
	 */
	public static Credential getCredentials(final NetHttpTransport httpTransport) throws IOException {
		InputStream in = SheetsHelper.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, JSON_FACTORY,
				clientSecrets, SCOPES)
						.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
						.setAccessType("offline").build();
		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static Map<String, Double> getSumOfAllCompanies(String sheetId)
			throws IOException, GeneralSecurityException {
		ValueRange response = getSpreadsheet(sheetId);
		Map<String, Double> additionMap = new HashMap<>();
		List<List<Object>> values = response.getValues();
		if (values != null && !values.isEmpty()) {
			Double sum = 0d;
			int defaultIndex = 7;
			for (List<Object> row : values) {
				for (int i = defaultIndex; i < row.size(); i++) {
					sum = sum + Double.parseDouble(row.get(defaultIndex).toString().replace("%", ""));
					defaultIndex++;
				}
				defaultIndex = 7;
				additionMap.put(row.get(3).toString(), sum);
				sum = 0d;
			}
		}
		return additionMap;
	}

	public static Map<String, Double> getDown20(String sheetId) throws IOException, GeneralSecurityException {
		Map<String, Double> additionMap = getSumOfAllCompanies(sheetId);
		Collection<Double> values = additionMap.values();
		List<Double> list = new ArrayList<>();
		for (Double value : values) {
			list.add(value);
		}
		Collections.sort(list);
		return getMap(list, additionMap, 4);
	}

	public static Map<String, Double> getTopCompanies(String sheetId, Integer companiesCount, Integer lastDaysCount)
			throws IOException, GeneralSecurityException {
		Map<String, Double> additionMap = getSumOfAllCompanies(sheetId);
		Collection<Double> values = additionMap.values();
		List<Double> list = new ArrayList<>();
		for (Double value : values) {
			list.add(value);
		}
		Collections.sort(list, Collections.reverseOrder());
		return getMap(list, additionMap, companiesCount);
	}

	private static Map<String, Double> getMap(List<Double> list, Map<String, Double> additionMap,
			Integer companiesCount) {
		String temp = "";
		Map<String, Double> map = new HashMap<>();
		for (int i = 0; i < companiesCount; i++) {
			Set<String> set = getKeys(additionMap, list.get(i));
			if (set.size() > 1) {
				for (String string : set) {
					temp = temp + " , " + string;
				}
				map.put(temp, list.get(i));
			} else {
				map.put(set.toArray()[0].toString(), list.get(i));
			}
		}
		return map;
	}

	private static <K, V> Set<K> getKeys(Map<K, V> map, V value) {
		Set<K> keys = new HashSet<>();
		for (Entry<K, V> entry : map.entrySet()) {
			if (entry.getValue().equals(value)) {
				keys.add(entry.getKey());
			}
		}
		return keys;
	}

	/**
	 * Prints the names and majors of students in a sample spreadsheet:
	 * https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
	 */
	public static void main(String... args) throws IOException, GeneralSecurityException {
		/*
		 * System.out.println("top***********************" + getTop20());
		 * System.out.println(); System.out.println();
		 * System.out.println("down***********************" + getDown20());
		 * System.out.println(); System.out.println(); System.out.println("sum*********"
		 * + getSumOfAllCompanies()); System.out.println(); System.out.println();
		 * System.out.println("3 dayPositive******" + getLast3daysPositive());
		 * System.out.println(); System.out.println();
		 * System.out.println("3 dayNegative******" + getLast3daysNegative());
		 */
	}

	public static Map<String, List<Object>> getLastdaysPositive(String sheetId, Integer lastDaysCount)
			throws GeneralSecurityException, IOException {
		ValueRange response = getSpreadsheet(sheetId);
		Map<String, List<Object>> map = new HashMap<>();
		List<List<Object>> values = response.getValues();
		if (values != null && !values.isEmpty()) {
			lastDaysCount = lastDaysCount + 7;
			for (int i = 7; i < lastDaysCount; i++) {
				for (List<Object> row : values) {
					if (row.size() > lastDaysCount
					/*
					 * && Double.parseDouble(row.get(lastDaysCount).toString().replace("%", "")) > 0
					 * && row.size() > lastDaysCount++ && row.size() > lastDaysCount + 2 &&
					 * Double.parseDouble(row.get(lastDaysCount + 2).toString().replace("%", "")) >
					 * 0 && Double.parseDouble(row.get(lastDaysCount++).toString().replace("%", ""))
					 * > 0
					 */) {

						map.put(row.get(4).toString(), Arrays.asList(row.get(lastDaysCount), row.get(lastDaysCount++),
								row.get(lastDaysCount + 2)));
					}
				}
			}

		}
		return map;
	}

	public static Map<String, List<Object>> getLast3daysNegative(String sheetId)
			throws GeneralSecurityException, IOException {
		ValueRange response = getSpreadsheet(sheetId);
		Map<String, List<Object>> map = new HashMap<>();
		List<List<Object>> values = response.getValues();
		if (values != null && !values.isEmpty()) {
			int defaultIndex = 7;
			int defaultIndexPos = 8;
			int defaultIndexPosPos = 9;
			for (List<Object> row : values) {
				if (row.size() > defaultIndex
						&& Double.parseDouble(row.get(defaultIndex).toString().replace("%", "")) < 0
						&& row.size() > defaultIndexPos && row.size() > defaultIndexPosPos
						&& Double.parseDouble(row.get(defaultIndexPosPos).toString().replace("%", "")) < 0
						&& Double.parseDouble(row.get(defaultIndexPos).toString().replace("%", "")) < 0) {

					map.put(row.get(4).toString(), Arrays.asList(row.get(defaultIndex), row.get(defaultIndexPos),
							row.get(defaultIndexPosPos)));
				}

			}
		}
		return map;
	}

	private static ValueRange getSpreadsheet(String sheetId) throws GeneralSecurityException, IOException {
		final NetHttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		final String range = "Class Data";
		Sheets service = new Sheets.Builder(httpTransport, JSON_FACTORY, getCredentials(httpTransport))
				.setApplicationName(APPLICATION_NAME).build();
		return service.spreadsheets().values().get(sheetId, range).execute();
	}

	public static Map<String, List<Double>> getDetails(String sheetId, CompanyStatus companyStatus,
			Integer lastDaysCount, Integer companiesCount) throws GeneralSecurityException, IOException {
		if (companyStatus != null && companyStatus.equals(CompanyStatus.GAINER)) {
			return getGainers(sheetId,lastDaysCount, companiesCount);
		}
		return getLoosers(sheetId, lastDaysCount, companiesCount);
	}

	private static Map<String, List<Double>> getLoosers(String sheetId, Integer lastDaysCount,
			Integer companiesCount) throws IOException, GeneralSecurityException {
		ValueRange response = getSpreadsheet(sheetId);
		List<List<Object>> values = response.getValues();
		Collections.reverse(values);
		return getData(values, lastDaysCount, companiesCount);
		
	}

	private static Map<String, List<Double>> getData(List<List<Object>> values, Integer lastDaysCount, Integer companiesCount) {
		List<Double> list = new ArrayList<>();
		Map<String, List<Double>> additionMap = new LinkedHashMap<>();
		int templastDaysCount = lastDaysCount + 7;
		if (values != null && !values.isEmpty()) {
			int defaultIndex = 7;
			int sumIndex = 5;
			int billanIndex = 2;
			int onlyOnce = 0;
			int defaultCompaniesCount = -1;
			for (List<Object> row : values) {
				defaultCompaniesCount++;
				if(companiesCount <= defaultCompaniesCount) {
					break;
				}
				for (int i = defaultIndex; i < row.size(); i++) {
					if (templastDaysCount == defaultIndex) {
						break;
					}
					if(onlyOnce == 0) {
						list.add(Double.parseDouble(row.get(sumIndex).toString().replace("%", "")));
						list.add((getDouble(billanIndex, row)));
						onlyOnce++;
					}
					list.add(Double.parseDouble(row.get(defaultIndex).toString().replace("%", "")));
					defaultIndex++;
				}
				defaultIndex = 7;
				if(templastDaysCount != (list.size() +  lastDaysCount + 1)) {
					int filledIndex = lastDaysCount - list.size();
					for(int i = -2 ; i< filledIndex; i++) {
						list.add(0d);
					}
				}
				additionMap.put(row.get(3).toString(), list);
				list = new ArrayList<>();
				onlyOnce = 0;
			}
		}
		additionMap.forEach((k,v) -> System.out.println("Key = "
	                + k + ", Value = " + v.size())); 
		return additionMap;
	}

	private static Map<String, List<Double>> getGainers(String sheetId, Integer lastDaysCount,
			Integer companiesCount) throws IOException, GeneralSecurityException {
		ValueRange response = getSpreadsheet(sheetId);
		List<List<Object>> values = response.getValues();
		return getData(values, lastDaysCount, companiesCount);
	}

	private static Double getDouble(int billanIndex, List<Object> row) {
		try {
			return Double.parseDouble(row.get(billanIndex).toString());
		} catch (Exception e) {
			return 0.0D;
		}

	}

}