package com.gdrive.drivelistfiles.enums;

public enum CompanyStatus {

	GAINER, LOOSER
}
